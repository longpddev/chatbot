import ChatApp from "./components/ChatApp";

export function App () {
  return (
    <>
      <ChatApp />
    </>
  )
}
