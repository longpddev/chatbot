import { useRef, useLayoutEffect } from "preact/compat";
import MessageOptions from "../MessageOptions";
import Message from "../Message";
import { shallow } from "zustand/shallow";
import useStore from "../../store";
import { CLIENT_ID } from "../../utils/constants";
import { isElementScrollToBottom } from "../../utils/ultis";

function Conversations () {
  const contentChatRef = useRef<HTMLDivElement>(null);
  const prevScrollHeightChatContainer = useRef<number | null>(null);

  const { bottomPositionOfChatContent, messageData, isNewChat } = useStore(
    (state) => ({
      bottomPositionOfChatContent: state.bottomPositionOfChatContent,
      messageData: state.messageData,
      isNewChat: state.isNewChat
    }),
    shallow
  );

  useLayoutEffect(() => {
    const savePrevScrollHeight = (height: number) => {
      prevScrollHeightChatContainer.current = height;
    };

    const scrollToEndOfChat = () => {
      const outerElement = contentChatRef.current;
      if (!outerElement) return;

      const { scrollHeight, clientHeight, scrollTop } = outerElement;

      const isChatContainerScroll = scrollHeight > clientHeight;
      if (!isChatContainerScroll) {
        savePrevScrollHeight(scrollHeight);
        return;
      }

      const scrollHeightChatBeforeHasMessage =
        prevScrollHeightChatContainer.current ?? scrollHeight;

      const isReachBottom = isElementScrollToBottom(
        scrollHeightChatBeforeHasMessage,
        scrollTop,
        clientHeight
      );

      const latestMessageIsFromUser =
        messageData[messageData.length - 1]?.userId === CLIENT_ID;

      const canScrollToBottomOfChat = isReachBottom || (!isReachBottom && latestMessageIsFromUser)
      if (canScrollToBottomOfChat) {
        outerElement.scrollTop = scrollHeight;
      }

      savePrevScrollHeight(scrollHeight);
    };

    scrollToEndOfChat();
  }, [messageData]);

  return (
    <div
      style={{ bottom: bottomPositionOfChatContent }}
      className="absolute inset-0 overflow-x-hidden overflow-y-auto px-6 pt-6"
      ref={contentChatRef}
    >
      <div className="chat-app__conversations">
        {messageData.map((message, index) => (
          <Message
            message={message}
            key={message.id}
            currentAndNextMessageIsSameUser={
              message.userId === messageData[index + 1]?.userId
            }
          />
        ))}
      </div>

      {isNewChat && <MessageOptions />}
    </div>
  );
}

export default Conversations;
