export const CHAT_APP_REPLY_MESSAGE_ID = 'chat-app-reply-message-id-preact';

export const BOT_ID = 'bot';

export const CLIENT_ID = 'client';

export const FAKE_BOT_DATA = [
  "Hi! \n Good morning",
  "How can I help you?",
  "Are you a company's customer?"
]

export const MESSAGE_OPTIONS = [
  "Just browsing!",
  "I’d like to learn more about Intercom",
  "I'm an Intercom customer with a question."
]