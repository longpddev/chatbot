export const SendMessageIcon = ({ className }: { className?: string }) => (
  <svg
      width={24}
      height={24}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <path
        d="M.027 22.887l2.028-8.779a.94.94 0 01.8-.72l11.336-1.174c.32-.027.32-.507 0-.56L2.855 10.558a.881.881 0 01-.8-.694L.027 1.113C-.159.366.641-.247 1.335.1L23.5 11.2a.934.934 0 010 1.655L1.335 23.9c-.694.346-1.494-.267-1.308-1.014z"
        fill="#2367C1"
      />
    </svg>
);
