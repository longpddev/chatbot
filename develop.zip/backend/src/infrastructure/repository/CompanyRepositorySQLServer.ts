export class CompanyRepositorySQLServer {}
