import { Configuration, OpenAIApi } from "openai";

export default class OpenAIConfiguration {
  private static config: OpenAIApi | undefined
  static get () {
    if(!this.config) {
      const configuration = new Configuration({
        apiKey: process.env.OPENAI_API_KEY,
      });
      
      this.config = new OpenAIApi(configuration);
    }

    return this.config
  }
}