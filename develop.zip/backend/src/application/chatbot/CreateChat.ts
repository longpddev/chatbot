import { Socket } from "socket.io";
import { ChatTheadList } from "../../domain/openai/ChatTheadList";
import ChatCompletion from "../../domain/openai/ChatCompletion";
import { ChatCompletionRequestMessage } from "openai";

export class CreateChat {
  private thread = new ChatTheadList()
  private chatCompletion = new ChatCompletion(this.thread)
  async execute(socket: Socket) {
    const id = socket.id
    console.log('--socket connect--', id)

    const setupMessage: ChatCompletionRequestMessage[] = [{
      role: "system",
      content: "you are a helpful assistant"
    }]

    setupMessage.forEach(item => this.thread.pushNew(item))

    socket.on('client:message:send', (message: string) => {
      console.log('---client message send---', message)
      if(this.chatCompletion.asking) return;
      
      this.thread.pushNew({
        role: 'user',
        content: message
      })

      this.chatCompletion.ask()
    })

    this.thread.on('add', (items) => {
      items.forEach(item => {
        if(item.message.role === 'user') return
        if(item.message.role === 'assistant' && ('function_call' in item.message)) return
        socket.emit('server:message:response', item)
      })
    })
  }
}
