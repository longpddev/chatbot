import { Request, Response } from "express";
import { SendQuestion } from "../../../application/chatbot/SendQuestion";
import { CreateChat } from "../../../application/chatbot/CreateChat";
import { Socket } from "socket.io";
export class ChatController {
  /**
   *
   */
  constructor() {}
  public static async sendQuestion(
    request: Request,
    res: Response
  ) {
    var sendQuestion = new SendQuestion();
    try {
      // var result = await sendQuestion.execute(request);
      res.status(201).json({ message: "User created successfully" });
      // return result;
    } catch (error) {
      res
        .status(500)
        .json({ error: "An error occurred while creating the user" });
      return null;
    }
  }

  public static async createChat(socket: Socket) {
    try {
      const createChat = new CreateChat();
      createChat.execute(socket)
    } catch (e) {
      socket.emit('server:error', (e as Error).toString())
    }
  }
}
