import { CompanyRepositorySQLServer } from "../../../infrastructure/repository/CompanyRepositorySQLServer";

const companyRepository = new CompanyRepositorySQLServer();

export class CompanyController{

}