import getCurrentWeather from './get-current-weather'

const functions = {
  getCurrentWeather
}

export default functions