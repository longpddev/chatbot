import { weatherApi } from "./api";

interface IFunResponse {
  content: string,
  raw: any
}

const getCurrentWeather = {
  type: {
    name: "getCurrentWeather",
    description: "Get the current weather in a given location",
    parameters: {
      type: "object",
      properties: {
        location: {
          type: "string",
          description: "The city and state, e.g. San Francisco, CA",
        },
      },
      required: ["location"],
    },
  },
  func: async ({location}: { location: string}): Promise<IFunResponse> => {
    let result = await weatherApi.GET('/data/2.5/weather', {
      q: location
    })
    return {
      content: `json data:  ${JSON.stringify(result)} `,
      raw: result
    }
  }
}

export default getCurrentWeather