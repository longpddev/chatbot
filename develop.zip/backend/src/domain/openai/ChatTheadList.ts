import EventEmitter from "events";
import IChatThread from "../entities/chat/ChatThread";
import crypto from 'crypto';

export class ChatTheadList<T extends IChatThread> extends Array<T> {
  public emitter = new EventEmitter()
  
  push (...items: T[]) {
    this.emitter.emit('add', items)
    return super.push(...items)
  }
  pushNew(message: T['message'], raw?: any) {
    this.push({
      id: crypto.randomBytes(20).toString('hex'),
      message,
      raw
    } as T)
  }

  updateBy(id: string, cb: (data: T) => T) {
    const index = this.findIndex(item => item.id === id);
    if(index === -1) return;

    this[index] = cb(this[index])
    this.emitter.emit('update', [id, this[index]])
  }

  exist(id: string) {
    return this.findIndex(item => item.id === id) !== -1
  }

  on(eventname: 'add', handle: (items: T[]) => void) {
    this.emitter.on(eventname, handle)
    return this;
  }

  optimizeMessage() {
    return this.map(item => item.message)
  }
}