import { ChatCompletionRequestMessage, ChatCompletionResponseMessage, CreateChatCompletionResponse, CreateChatCompletionResponseChoicesInner } from "openai";
import functions from "./functions";
import OpenAIConfiguration from "../../infrastructure/openai/OpenAIConfiguration";
import IChatThread from "../entities/chat/ChatThread";
import { ChatTheadList } from "./ChatTheadList";
import { IncomingMessage } from "http";
import {createParser, ParsedEvent, ReconnectInterval} from 'eventsource-parser'
const STREAM_DATA_END = Symbol('STREAM_DATA_END')

interface CreateChatCompletionResponseChoicesDeltaInner extends Omit<CreateChatCompletionResponseChoicesInner, 'message'> {
  delta: ChatCompletionResponseMessage
}

interface CreateChatCompletionStreamResponse extends Omit<CreateChatCompletionResponse, 'choices'> {
  choices: Array<CreateChatCompletionResponseChoicesDeltaInner>
}

export default class ChatCompletion {
  public asking = false;
  constructor (
    private readonly messages: ChatTheadList<IChatThread>
  ) {}

  private mergeResponse(origin: CreateChatCompletionResponse, delta: CreateChatCompletionStreamResponse): CreateChatCompletionResponse {
    return {
      ...origin,
      choices: origin.choices.map((item, index) => {
        return {
          ...delta.choices[index]
        }
      })
    }
  }

  async makeRequest(stream: boolean = false): Promise<any> {
    let result = await OpenAIConfiguration.get().createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: this.messages.optimizeMessage(),
      functions: Object.entries(functions).map(([funcName, value]) => ({...value.type, name: funcName})),
      function_call: 'auto',
      temperature: 0.2,
      max_tokens: 256,
      top_p: 1,
      frequency_penalty: 0,
      presence_penalty: 0,
      stream
    }, stream ? {
      responseType: 'stream'
    } : undefined);

    if ( stream ) {
      return new Promise ((res, rej) => {
        const data = (result.data as unknown as IncomingMessage)
        const parser = createParser(parsed => {
          if(parsed.type === 'event') {
            const { id, event, data} = parsed
            if(data === '[DONE]') {

            } else {
              const response = JSON.parse(data) as CreateChatCompletionStreamResponse;
              if(this.messages.exist(response.id)) {

              } else {
                this.messages.push({
                  id: response.id,
                  message: response.choices[0].delta,
                  raw: undefined
                })
              }
              console.log(JSON.parse(data))
            }
          } else {
            console.log('We should set reconnect interval to %d milliseconds', parsed.value)
          }
        })
        data.on('data', (buffer: Buffer) => parser.feed(buffer.toString()))
      })
    } 

    return result
  }

  async ask():  Promise<IChatThread | undefined> {
    this.asking = true;
    try {
      const result = await this.makeRequest(false);
      const data = result.data;
      const answer = data.choices[0]
      const message = answer.message;
      let chatMessage: IChatThread | undefined 
      if(message) {
        chatMessage = {
          id: data.id,
          message,
          raw: undefined
        }
        this.messages.push(chatMessage as IChatThread)
      }
      if(answer.finish_reason === "function_call" && message) {
        const functionName = message?.function_call?.name
        const functionArgs = message?.function_call?.arguments
        if(functionName && (functionName in functions) && functionArgs) {
          const functionResponse = await functions[functionName as keyof typeof functions].func(JSON.parse(functionArgs))
          
          this.messages.pushNew({
            role: 'function',
            content: functionResponse.content,
            name: functionName
          }, functionResponse.raw)
    
          const data = await this.ask()
          return data
        }
      }
      return chatMessage;
    } finally {
      this.asking = false
    }
  }  
  // async ask(): Promise<CreateChatCompletionResponseChoicesInner | undefined> {
//   async ask() {
//     try {
//       const result = await OpenAIConfiguration.get().createChatCompletion({
//         model: "gpt-3.5-turbo",
//         messages: this.messages,
//         functions: Object.entries(functions).map(([funcName, value]) => ({...value.type, name: funcName})),
//         function_call: 'auto',
//         temperature: 1,
//         max_tokens: 256,
//         top_p: 1,
//         frequency_penalty: 0,
//         presence_penalty: 0,
//         stream: true
//       },{
//         responseType: "stream"
//       });

//       (result.data as unknown as any).on('data', (data: Uint8Array) => {
//         console.log(data.toString())
//       })
//       // console.log(typeof result.data)
//       // console.log(result.data)
//       // const answer = result.data.choices[0]
//       // const message = answer.message;
//       // if(message) this.messages.push(message)
//       // if(answer.finish_reason === "function_call" && message) {
//       //   const functionName = message?.function_call?.name
//       //   const functionArgs = message?.function_call?.arguments
//       //   if(functionName && (functionName in functions) && functionArgs) {
//       //     const functionResponse = await functions[functionName as keyof typeof functions].func(JSON.parse(functionArgs))
          
//       //     this.messages.push({
//       //       role: 'function',
//       //       content: functionResponse,
//       //       name: functionName
//       //     })
    
//       //     return await this.ask()
//       //   }
//       // }
//       // return answer;
//     } catch (e) {
//       console.error(e)
//     }
//   }  
}