export class User {
  /**
   *
   */
  constructor() {
  }
}
