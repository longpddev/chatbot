export class UserRepository {}
