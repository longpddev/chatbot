export interface Company {
  conpanyCode: String;
}
