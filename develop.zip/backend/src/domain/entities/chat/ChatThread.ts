import { ChatCompletionRequestMessage } from "openai"

export default interface IChatThread {
  id: string
  message: ChatCompletionRequestMessage,
  raw: any
}