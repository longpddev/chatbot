export interface QuestionInputDto {
  questionText: String;
}
