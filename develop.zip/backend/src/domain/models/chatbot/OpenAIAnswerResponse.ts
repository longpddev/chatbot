export interface OpenAIAnswerResponse {
  answerText: String;
}
